import os
"""
RouteMesh — Builder 1: The Brain (router_engine.py)
Implements:
1. Sub-15ms Hybrid Semantic Embedding Engine (Word + Character N-Gram Vectorizer with optional SentenceTransformers)
2. Cosine Similarity Lookup (>0.92 threshold) against Redis / In-Memory Vector Store
3. Deterministic Negation & Antonym Guard (prevents false cache hits on 'with' vs 'without' / 'not')
4. Task Complexity Classifier ('fast' vs 'reasoning' tier routing)
"""

import time
import json
import re
import hashlib
import numpy as np

# Optional Sentence-Transformers support if installed & cached, otherwise uses ultra-fast 512-dim hybrid vectorizer
USE_ST = False
_st_model = None
if os.getenv("USE_SENTENCE_TRANSFORMERS", "false").lower() == "true":
    try:
        from sentence_transformers import SentenceTransformer
        _st_model = SentenceTransformer("all-MiniLM-L6-v2")
        USE_ST = True
    except Exception:
        USE_ST = False

LOCAL_MEMORY_CACHE = []
CACHE_KEY = "routemesh:semantic_cache_v1"
SIMILARITY_THRESHOLD = 0.92

STOPWORDS = {"the", "a", "an", "please", "can", "you", "tell", "me", "how", "to", "do", "i", "in", "of", "for"}

NEGATION_WORDS = {
    "not", "never", "no", "without", "dont", "don't", "cannot", "cant", "can't",
    "avoid", "except", "exclude", "excluding", "neither", "nor", "non"
}

REASONING_KEYWORDS = {
    "prove", "optimize", "complexity", "algorithm", "architecture", "debug",
    "refactor", "concurrency", "deadlock", "dynamic programming", "time complexity",
    "distributed", "sql", "regex", "typescript", "python", "implement", "design",
    "dijkstra", "consensus", "raft", "paxos", "asymptotic", "security", "jailbreak",
    "active-active", "kubernetes", "levenshtein"
}


def _stable_hash(token: str, dim: int = 512) -> int:
    h = hashlib.md5(token.encode("utf-8")).digest()
    return int.from_bytes(h[:4], "little") % dim


def compute_embedding(text: str) -> list[float]:
    """
    Computes L2-normalized 512-dim semantic vector combining normalized word stems,
    word bigrams, and character 3-grams for <2ms sub-millisecond similarity matching.
    """
    clean = re.sub(r"[^a-z0-9\s]", " ", text.strip().lower())
    tokens = [t for t in clean.split() if t and t not in STOPWORDS]
    if not tokens:
        tokens = clean.split()

    vec = np.zeros(512, dtype=np.float32)

    # 1. Unigram token features (weight 3.0)
    for t in tokens:
        stem = t[:-1] if len(t) > 4 and t.endswith("s") else t
        vec[_stable_hash(f"w:{stem}", 512)] += 3.0

    # 2. Word bigram features (weight 2.0)
    for i in range(len(tokens) - 1):
        bg = f"bg:{tokens[i]}_{tokens[i+1]}"
        vec[_stable_hash(bg, 512)] += 2.0

    # 3. Character 3-gram features for typo & paraphrase resilience (weight 0.6)
    joined = " ".join(tokens)
    padded = f" {joined} "
    for i in range(len(padded) - 2):
        gram = f"c:{padded[i:i+3]}"
        vec[_stable_hash(gram, 512)] += 0.6

    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


def has_negation_flip(prompt_a: str, prompt_b: str) -> bool:
    """
    Deterministic Negation Guard:
    If one prompt contains a negation modifier ('without recursion', 'not in top 5')
    and the other does not, block the cache hit even if cosine similarity > 0.92.
    """
    tokens_a = set(re.findall(r"\b\w+\b", prompt_a.lower()))
    tokens_b = set(re.findall(r"\b\w+\b", prompt_b.lower()))
    neg_a = tokens_a & NEGATION_WORDS
    neg_b = tokens_b & NEGATION_WORDS
    return bool(neg_a) != bool(neg_b)


def score_complexity(prompt: str) -> dict:
    """
    Evaluates prompt complexity in <1ms and assigns either:
    - 'fast' tier (Gemini 2.5 Flash / Groq Llama 3.1 8B)
    - 'reasoning' tier (Gemini 2.5 Pro / Groq Llama 3.3 70B)
    """
    words = prompt.split()
    lower = prompt.lower()
    matched_keywords = [kw for kw in REASONING_KEYWORDS if kw in lower]

    score = 0.15
    if len(words) > 28:
        score += 0.35
    if "```" in prompt or "SELECT " in prompt.upper():
        score += 0.30
    score += min(0.55, len(matched_keywords) * 0.22)
    score = round(min(1.0, score), 2)

    tier = "reasoning" if (score >= 0.55 or len(matched_keywords) >= 2 or len(words) > 35) else "fast"
    return {
        "tier": tier,
        "complexity_score": score,
        "matched_signals": matched_keywords[:4]
    }


async def evaluate_prompt(prompt: str, redis_client=None, custom_threshold: float = SIMILARITY_THRESHOLD) -> dict:
    t0 = time.perf_counter()
    comp = score_complexity(prompt)
    tier = comp["tier"]
    query_vec = np.array(compute_embedding(prompt), dtype=np.float32)

    entries = []
    cache_backend = "in-memory"
    if redis_client is not None:
        try:
            raw_items = await redis_client.lrange(CACHE_KEY, 0, 199)
            entries = [json.loads(x) for x in raw_items]
            cache_backend = "redis-key-value"
        except Exception:
            entries = LOCAL_MEMORY_CACHE
    else:
        entries = LOCAL_MEMORY_CACHE

    best_score = 0.0
    best_response = None
    best_matched_prompt = None
    negation_blocked = False

    for item in entries:
        cached_vec = np.array(item["vector"], dtype=np.float32)
        score = float(np.dot(query_vec, cached_vec))

        if score >= custom_threshold and has_negation_flip(prompt, item["prompt"]):
            negation_blocked = True
            continue

        if score > best_score:
            best_score = score
            best_response = item["response"]
            best_matched_prompt = item["prompt"]

    router_ms = round((time.perf_counter() - t0) * 1000, 2)

    if best_score >= custom_threshold and best_response:
        return {
            "cache_hit": True,
            "cached_response": best_response,
            "matched_prompt": best_matched_prompt,
            "similarity_score": round(best_score, 4),
            "negation_guard_blocked": False,
            "tier": tier,
            "complexity_score": comp["complexity_score"],
            "router_latency_ms": router_ms,
            "cache_backend": cache_backend
        }

    return {
        "cache_hit": False,
        "cached_response": None,
        "matched_prompt": None,
        "similarity_score": round(best_score, 4),
        "negation_guard_blocked": negation_blocked,
        "tier": tier,
        "complexity_score": comp["complexity_score"],
        "router_latency_ms": router_ms,
        "cache_backend": cache_backend
    }


async def store_in_cache(prompt: str, response_text: str, redis_client=None):
    entry = {
        "prompt": prompt,
        "vector": compute_embedding(prompt),
        "response": response_text,
        "stored_at": time.time()
    }
    LOCAL_MEMORY_CACHE.insert(0, entry)
    if len(LOCAL_MEMORY_CACHE) > 200:
        LOCAL_MEMORY_CACHE.pop()

    if redis_client is not None:
        try:
            await redis_client.lpush(CACHE_KEY, json.dumps(entry))
            await redis_client.ltrim(CACHE_KEY, 0, 199)
        except Exception:
            pass
