import React, { useState, useEffect } from 'react';
import {
  Zap,
  ShieldAlert,
  Database,
  DollarSign,
  Activity,
  Play,
  Trash2,
  Send,
  Cpu,
  CheckCircle2,
  Server,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

const API_BASE = (import.meta as any).env?.VITE_API_URL || '';

const QUICK_TEST_PROMPTS = [
  {
    label: '1. Coding FAQ (Test Cache)',
    text: 'How do I reverse a singly linked list in Python?',
  },
  {
    label: '2. Negation Guard (Must Not Hit Cache!)',
    text: 'How do I reverse a singly linked list in Python without recursion?',
  },
  {
    label: '3. Fast Tier (Simple JSON)',
    text: 'Convert this text to JSON: Name=Aarav Sharma, Role=SRE, Region=Singapore',
  },
  {
    label: '4. Reasoning Tier (Distributed System)',
    text: 'Design a distributed rate-limiting algorithm in Python using Redis token buckets with concurrency safety and explain its time complexity.',
  },
];

export default function App() {
  const [stats, setStats] = useState<any>({
    total_requests: 0,
    cache_hits: 0,
    cache_hit_rate_pct: 0,
    negation_blocks: 0,
    failovers_handled: 0,
    fast_tier_calls: 0,
    reasoning_tier_calls: 0,
    total_saved_usd: 0,
    actual_spend_usd: 0,
    baseline_spend_usd: 0,
    savings_pct: 0,
    avg_latency_ms: 0,
    avg_cache_latency_ms: 0,
    chaos_outage_active: false,
    redis_connected: false,
    cache_backend: 'In-Memory Vector Cache',
    recent_logs: [],
  });

  const [prompt, setPrompt] = useState(QUICK_TEST_PROMPTS[0].text);
  const [lastReply, setLastReply] = useState<string>('');
  const [lastMeta, setLastMeta] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [benchLoading, setBenchLoading] = useState(false);
  const [burstSize, setBurstSize] = useState<number>(12);

  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/stats`);
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch {
      // ignore transient poll errors
    }
  };

  useEffect(() => {
    fetchStats();
    const id = setInterval(fetchStats, 1200);
    return () => clearInterval(id);
  }, []);

  const sendPrompt = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const targetPrompt = customPrompt ?? prompt;
    if (!targetPrompt.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'routemesh-auto',
          messages: [{ role: 'user', content: targetPrompt }],
        }),
      });
      const data = await res.json();
      setLastReply(data.choices?.[0]?.message?.content || '');
      setLastMeta(data.routemesh_meta);
      await fetchStats();
    } finally {
      setLoading(false);
    }
  };

  const toggleChaos = async () => {
    await fetch(`${API_BASE}/api/chaos/toggle`, { method: 'POST' });
    await fetchStats();
  };

  const runBenchmark = async (count: number) => {
    setBenchLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/benchmark/run?count=${count}`, {
        method: 'POST',
      });
      if (res.ok) {
        await fetchStats();
      }
    } finally {
      setBenchLoading(false);
    }
  };

  const clearCache = async () => {
    await fetch(`${API_BASE}/api/cache/clear`, { method: 'POST' });
    setLastReply('');
    setLastMeta(null);
    await fetchStats();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 font-sans">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Command Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl">
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-600/20 border border-indigo-500/40">
                <Zap className="w-6 h-6 text-indigo-400" />
              </div>
              <h1 className="text-2xl font-extrabold tracking-tight text-white">RouteMesh</h1>
              <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full font-mono font-semibold">
                v1.0 • OpenAI-Compatible Proxy
              </span>
              <span className="text-xs bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-mono flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {stats.cache_backend}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1.5">
              Semantic Vector Cache (&gt;0.92 Cosine + Negation Guard) • &lt;15ms Complexity Router • Zero-Downtime Circuit Breaker
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={toggleChaos}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 border transition-all cursor-pointer ${
                stats.chaos_outage_active
                  ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/30 animate-pulse'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              {stats.chaos_outage_active
                ? 'CHAOS ACTIVE: PRIMARY 429 OUTAGE'
                : 'Simulate Primary Outage (HTTP 429)'}
            </button>

            <div className="flex items-center bg-slate-800 border border-slate-700 rounded-xl p-0.5">
              <button
                onClick={() => setBurstSize(12)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                  burstSize === 12 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                12 Prompts
              </button>
              <button
                onClick={() => setBurstSize(50)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                  burstSize === 50 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                50 Prompts
              </button>
            </div>

            <button
              onClick={() => runBenchmark(burstSize)}
              disabled={benchLoading}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              <Play className="w-4 h-4" />
              {benchLoading ? `Running ${burstSize}-Prompt Burst...` : `Run ${burstSize}-Prompt Burst`}
            </button>

            <button
              onClick={clearCache}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 border border-slate-700 transition-colors cursor-pointer"
              title="Clear Semantic Cache & Reset Telemetry"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
            <div className="flex justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
              <span>Semantic Cache Hit Rate</span>
              <Database className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400 mt-2">
              {stats.cache_hit_rate_pct}%
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center justify-between">
              <span>
                {stats.cache_hits} / {stats.total_requests} hits ({stats.avg_cache_latency_ms} ms avg)
              </span>
              {stats.negation_blocks > 0 && (
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded border border-purple-500/30">
                  {stats.negation_blocks} Negation Guarded
                </span>
              )}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
            <div className="flex justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
              <span>Average Gateway Latency</span>
              <Activity className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-3xl font-extrabold text-white mt-2">
              {stats.avg_latency_ms} <span className="text-lg font-normal text-slate-400">ms</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Fast Tier: <strong className="text-indigo-300">{stats.fast_tier_calls}</strong> • Reasoning Tier:{' '}
              <strong className="text-purple-300">{stats.reasoning_tier_calls}</strong>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
            <div className="flex justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
              <span>Circuit-Breaker Failovers</span>
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-3xl font-extrabold text-amber-400 mt-2">
              {stats.failovers_handled}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              100% Request Uptime (0 Dropped Packets)
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
            <div className="flex justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
              <span>Token Spend Saved ({stats.savings_pct}%)</span>
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400 mt-2">
              ${stats.total_saved_usd.toFixed(4)}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              RouteMesh: <strong className="text-white">${stats.actual_spend_usd.toFixed(4)}</strong> vs Naive:{' '}
              <span className="line-through text-slate-500">${stats.baseline_spend_usd.toFixed(4)}</span>
            </div>
          </div>
        </div>

        {/* Main Split Grid: Playground (5 cols) + Live Telemetry Stream (7 cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Interactive Prompt Playground */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Live Proxy Playground
                </h2>
                <span className="text-[11px] font-mono text-slate-400">POST /v1/chat/completions</span>
              </div>

              {/* 1-Click Preset Pills for Judges */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-400 font-semibold block">
                  1-Click Judge Demo Presets:
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {QUICK_TEST_PROMPTS.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setPrompt(item.text);
                        sendPrompt(undefined, item.text);
                      }}
                      className="text-left text-[11px] px-2.5 py-2 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors truncate cursor-pointer"
                      title={item.text}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <form onSubmit={(e) => sendPrompt(e)} className="space-y-3">
                <textarea
                  rows={3}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-indigo-500"
                  placeholder="Enter any prompt to route through RouteMesh..."
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  {loading ? 'Routing Request...' : 'Send Prompt Through RouteMesh'}
                </button>
              </form>

              {/* Response & Routing Decision Inspector Card */}
              {lastMeta && (
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                    <div className="flex items-center gap-2">
                      {lastMeta.cache_hit ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono font-bold text-[10px]">
                          ⚡ SEMANTIC CACHE HIT
                        </span>
                      ) : lastMeta.failover_triggered ? (
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono font-bold text-[10px]">
                          🛡️ CIRCUIT BREAKER FAILOVER
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono font-bold text-[10px]">
                          🚀 UPSTREAM DISPATCH
                        </span>
                      )}
                      <span className="font-mono text-slate-300 font-semibold">{lastMeta.model_used}</span>
                    </div>
                    <span className="font-mono font-extrabold text-emerald-400 text-sm">
                      {lastMeta.total_latency_ms} ms
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-[11px] font-mono bg-slate-900/90 p-2.5 rounded-lg border border-slate-800/80">
                    <div>
                      <span className="text-slate-500 block text-[9px] uppercase">Complexity Tier</span>
                      <span className="text-white font-bold uppercase">{lastMeta.tier}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px] uppercase">Cosine Sim</span>
                      <span className="text-indigo-300 font-bold">{lastMeta.similarity_score}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px] uppercase">Negation Guard</span>
                      <span className={lastMeta.negation_guard_blocked ? 'text-purple-300 font-bold' : 'text-slate-400'}>
                        {lastMeta.negation_guard_blocked ? 'BLOCKED FALSE HIT' : 'PASS'}
                      </span>
                    </div>
                  </div>

                  <div className="text-slate-300 leading-relaxed max-h-44 overflow-y-auto whitespace-pre-wrap font-sans pt-1">
                    {lastReply}
                  </div>
                </div>
              )}
            </div>

            {/* Naive vs RouteMesh Visual Comparison Bar */}
            <div className="pt-4 border-t border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
                <span>Cost Efficiency vs Direct Frontier LLM Calls</span>
                <span className="text-emerald-400 font-mono font-bold">{stats.savings_pct}% Saved</span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300"
                  style={{ width: `${Math.min(100, Math.max(8, stats.savings_pct))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Right Column: Real-Time Telemetry Stream Table */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                Real-Time Request Telemetry Stream ({stats.recent_logs.length})
              </h2>
              <span className="text-[11px] text-slate-400 font-mono">
                Auto-refreshing every 1.2s
              </span>
            </div>

            <div className="overflow-x-auto flex-1 max-h-[460px]">
              {stats.recent_logs.length === 0 ? (
                <div className="h-72 flex flex-col items-center justify-center text-slate-500 text-xs space-y-2">
                  <Cpu className="w-8 h-8 text-slate-700" />
                  <p>No requests logged yet. Click a preset or "Run 12-Prompt Burst" above!</p>
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead className="text-slate-400 border-b border-slate-800 uppercase text-[10px] sticky top-0 bg-slate-900">
                    <tr>
                      <th className="pb-2.5">Prompt</th>
                      <th className="pb-2.5">Route / Resolution</th>
                      <th className="pb-2.5">Tier</th>
                      <th className="pb-2.5">Cosine</th>
                      <th className="pb-2.5 text-right">Latency</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {stats.recent_logs.map((log: any) => (
                      <tr key={log.request_id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-2.5 pr-3 font-sans text-slate-200 max-w-[210px] truncate" title={log.prompt_preview}>
                          {log.prompt_preview}
                        </td>
                        <td className="py-2.5 pr-2">
                          {log.cache_hit ? (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                              ⚡ SEMANTIC CACHE HIT
                            </span>
                          ) : log.negation_guard_blocked ? (
                            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold">
                              🛡️ NEGATION GUARDED ({log.model_used})
                            </span>
                          ) : log.failover_triggered ? (
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                              🔄 FAILOVER: {log.model_used}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px]">
                              {log.model_used}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 uppercase text-[10px]">
                          <span
                            className={
                              log.tier === 'reasoning'
                                ? 'text-purple-300 font-bold'
                                : 'text-slate-400'
                            }
                          >
                            {log.tier}
                          </span>
                        </td>
                        <td className="py-2.5 text-slate-400">{log.similarity_score}</td>
                        <td className="py-2.5 text-right font-bold text-white">
                          {log.total_latency_ms} ms
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
