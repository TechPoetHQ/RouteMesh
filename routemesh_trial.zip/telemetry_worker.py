"""
RouteMesh — Render Background Worker (telemetry_worker.py)
Monitors Redis telemetry stream for token spend spikes and provider error rate anomalies.
"""
import os
import time
import json
import asyncio
import redis.asyncio as aioredis
from dotenv import load_dotenv

load_dotenv()

async def run_worker():
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
    print(f"[RouteMesh Worker] Starting telemetry monitor on {redis_url}...")
    while True:
        try:
            client = aioredis.from_url(redis_url, decode_responses=True, socket_connect_timeout=3.0)
            await client.ping()
            cache_len = await client.llen("routemesh:semantic_cache_v1")
            print(f"[RouteMesh Worker] Health OK | Active semantic vectors in Redis: {cache_len}")
            await client.aclose()
        except Exception as e:
            print(f"[RouteMesh Worker] Redis standby ({e}) - retrying in 15s...")
        await asyncio.sleep(15)

if __name__ == "__main__":
    asyncio.run(run_worker())
