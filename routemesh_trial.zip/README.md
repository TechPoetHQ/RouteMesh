# RouteMesh 🌐⚡

> **Low-Latency OpenAI-Compatible LLM Proxy Gateway with Semantic Vector Caching, Negation Guard & Automated Circuit-Breaker Failover**

## Quick Start (1-Command Run in GitHub Codespaces or Local Terminal)

```bash
chmod +x start.sh
./start.sh
```

Or run the two terminals separately:

**Terminal 1 (FastAPI Proxy Gateway on Port 8000):**
```bash
pip install -r requirements.txt
uvicorn gateway_api:app --reload --host 0.0.0.0 --port 8000
```

**Terminal 2 (React Command Center UI on Port 5173):**
```bash
cd dashboard-ui
npm install
npm run dev
```

## Pre-Configured Credentials
The `.env` file is already pre-loaded with:
- **Render Redis Internal URL:** `redis://red-dbf1dnom7kps73fdubl0:6379` (with automatic sub-millisecond In-Memory Vector Store fallback when running outside Render's private Singapore network)
- **Gemini Primary API Key** & **Groq Instant LPU Failover Key**
