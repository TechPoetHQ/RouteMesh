#!/usr/bin/env bash
set -e

echo "===================================================="
echo " Starting RouteMesh (FastAPI Gateway + React UI)..."
echo "===================================================="

echo "[1/3] Installing Python backend dependencies..."
pip install -q -r requirements.txt

echo "[2/3] Installing React dashboard dependencies..."
cd dashboard-ui
npm install --silent
cd ..

echo "[3/3] Launching FastAPI (port 8000) & Vite UI (port 5173)..."
uvicorn gateway_api:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

cd dashboard-ui
npm run dev -- --host 0.0.0.0 --port 5173

kill $BACKEND_PID 2>/dev/null || true
