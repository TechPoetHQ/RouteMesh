@echo off
echo ====================================================
echo  Starting RouteMesh (FastAPI Gateway + React UI)...
echo ====================================================
pip install -r requirements.txt
start cmd /k "uvicorn gateway_api:app --reload --host 0.0.0.0 --port 8000"
cd dashboard-ui
call npm install
call npm run dev
